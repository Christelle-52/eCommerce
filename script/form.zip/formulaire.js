inputText = [...document.querySelectorAll('input[type="text"]')];
inputPass = [...document.querySelectorAll('input[type="password"]')];
inputEmail = document.querySelector('input[type="email"]');
regExpEmail = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(inputEmail.value);
// console.log(regExpEmail);

function verifierMdp(mdp) {
  return /^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])(?=.*[a-zA-Z]).{8,}$/.test(mdp);
};

 function verifierEmail() {
  if (!regExpEmail) {
    inputEmail.placeholder = "Email invalide";
    inputEmail.style.boxShadow = "5px 5px 5px red";
  }
  else {
    inputEmail.style.boxShadow = "none";
  }
};

function verifierText() {
  for (const input of inputText) {
    // console.log(input.type);
    if (input.value.length < 3) {
      input.placeholder = "3 caractères minimum";
      input.style.boxShadow = "5px 5px 5px red";
      // console.log('champ vide');
    }
    else {
      // console.log('champ ok');
      input.style.boxShadow = "none";
    }
  };
};

function verifierPass() {
  for (const input of inputPass) {
    // console.log(input);
    if (!verifierMdp(input.value)) {
      input.placeholder = "8 car mini, 1 Maj, 1 car spécial et 1 chiffre";
      input.style.boxShadow = "5px 5px 5px red";
      // console.log(input.value);
    }
    else if (input[0].value === input[1].value) {
      // console.log('champ ok');
      input.style.boxShadow = "none";
    }
  };
};

function verifierForm() {

 return (!verifierText() || !verifierEmail() || !verifierPass()) 
}

// form.addEventListener('submit', e => {
//   e.preventDefault(); // Empêcher le formulaire de se soumettre normalement
//   verifierForm();
// });
