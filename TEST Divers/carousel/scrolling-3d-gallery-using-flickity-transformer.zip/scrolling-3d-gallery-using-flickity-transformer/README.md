# Scrolling 3d Gallery using Flickity Transformer

A Pen created on CodePen.io. Original URL: [https://codepen.io/coder787/pen/vYgjamR](https://codepen.io/coder787/pen/vYgjamR).

For the codepen challenge 'scrolling' I modified Flickity Transformer to allow scrolling with mouse wheel (you can also use drag as normal) , see example without mouse scrolling here: 

https://codepen.io/elcontraption/pen/RGPboR