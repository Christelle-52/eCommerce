# Simple photo carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/slack/pen/PJbEaY](https://codepen.io/slack/pen/PJbEaY).

A simple carousel for photo images with parallax