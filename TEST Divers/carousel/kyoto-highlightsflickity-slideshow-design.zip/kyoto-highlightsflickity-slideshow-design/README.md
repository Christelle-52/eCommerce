# "Kyoto Highlights" - Flickity Slideshow [DESIGN]

A Pen created on CodePen.io. Original URL: [https://codepen.io/RaduBratan/pen/ZEQPQWq](https://codepen.io/RaduBratan/pen/ZEQPQWq).

Concept by Nono Umasy: https://dribbble.com/shots/13869975-Kyoto-Highlights-Slideshow-Component