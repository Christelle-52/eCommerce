# Auto Rotate Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/PedalsUp/pen/ZErypwK](https://codepen.io/PedalsUp/pen/ZErypwK).

hello coders, please check the auto-rotate slider for the frontend purpose, this pen contains the image slider with the jquery logic to loop them in every 4 second. Have a look and share the pen