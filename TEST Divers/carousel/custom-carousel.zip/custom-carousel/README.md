# Custom Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/collincodes/pen/aGvmNx](https://codepen.io/collincodes/pen/aGvmNx).

A custom carousel created using some jQuery because it sounded fun.